import 'package:flutter/material.dart';

void main() {
  runApp(ExpenseTrackerApp());
}

class ExpenseTrackerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ExpenseTrackerHomePage(),
    );
  }
}

class ExpenseTrackerHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expense Tracker'),
        actions: [
          CircleAvatar(
            backgroundImage:
                AssetImage('assets/images'), // Replace with your asset
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BalanceInfo(
              currentBalance: 34000,
              targetedBudget: 33000,
              totalIncome: 34000,
              totalExpenses: 17000,
            ),
            SizedBox(height: 16.0),
            CurrentBalances(),
            SizedBox(height: 16.0),
            RecentTransactions(),
          ],
        ),
      ),
    );
  }
}

class BalanceInfo extends StatelessWidget {
  final int currentBalance;
  final int targetedBudget;
  final int totalIncome;
  final int totalExpenses;

  BalanceInfo({
    required this.currentBalance,
    required this.targetedBudget,
    required this.totalIncome,
    required this.totalExpenses,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Current Balance',
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            ),
            Text('Rs. $currentBalance'),
            SizedBox(height: 8.0),
            Text(
              'Targeted Budget',
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            ),
            Text('Rs. $targetedBudget'),
            SizedBox(height: 8.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Total Income'),
                    Text('Rs. $totalIncome'),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Total Expenses'),
                    Text('Rs. $totalExpenses'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CurrentBalances extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        BalanceCard(
          title: 'NIBL',
          amount: 43000,
          monthChange: 2000,
          icon: Icons.account_balance,
        ),
        BalanceCard(
          title: 'eSewa',
          amount: 8000,
          monthChange: 3200,
          icon: Icons.account_balance_wallet,
        ),
        // Add more BalanceCard widgets here if needed
      ],
    );
  }
}

class BalanceCard extends StatelessWidget {
  final String title;
  final int amount;
  final int monthChange;
  final IconData icon;

  BalanceCard({
    required this.title,
    required this.amount,
    required this.monthChange,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 30.0),
            Text(
              title,
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
            ),
            Text('Rs. $amount'),
            Text('Rs. $monthChange this month'),
          ],
        ),
      ),
    );
  }
}

class RecentTransactions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Transactions',
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            Text('See all'),
          ],
        ),
        SizedBox(height: 8.0),
        TransactionItem(
          date: '17th Jan, 2024',
          title: 'Family dinner',
          amount: 7000,
          icon: Icons.local_dining,
        ),
        TransactionItem(
          date: '14th Jan, 2024',
          title: 'Insurance',
          amount: 17000,
          icon: Icons.security,
        ),
        TransactionItem(
          date: '12th Jan, 2024',
          title: 'Bike Repair',
          amount: 3000,
          icon: Icons.build,
        ),
        TransactionItem(
          date: '9th Jan, 2024',
          title: 'Rent',
          amount: 500,
          icon: Icons.home,
        ),
        TransactionItem(
          date: '9th Jan, 2024',
          title: 'Lunch',
          amount: 500,
          icon: Icons.lunch_dining,
        ),
      ],
    );
  }
}

class TransactionItem extends StatelessWidget {
  final String date;
  final String title;
  final int amount;
  final IconData icon;

  TransactionItem({
    required this.date,
    required this.title,
    required this.amount,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, size: 30.0),
      title: Text(title),
      subtitle: Text(date),
      trailing: Text('Rs. $amount'),
    );
  }
}
