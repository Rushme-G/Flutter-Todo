import 'package:flutter/material.dart';

class SummaryTransaction extends StatelessWidget {
  const SummaryTransaction({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      color: Colors.red,
      margin: EdgeInsets.only(bottom: 16),
    );
  }
}
