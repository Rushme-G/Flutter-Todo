import 'package:expenses/screens/main/summary_accounts.dart';
import 'package:expenses/screens/main/summary_home.dart';
// import 'package:expenses/screens/main/summary_transaction.dart';
import 'package:flutter/material.dart';

class Mainscreen extends StatelessWidget {
  const Mainscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: const Column(
        children: [
          SummaryHome(),
          // SummaryAccounts(),
          // SummaryTransaction()
        ],
      ),
    );
  }
}
