import 'package:expenses/widgets/homescreens/balancecard.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Currentbalance2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Balancecard(
            title: 'NIBL          ',
            amount: 43000,
            monthChange: 2000,
            icon: Icons.account_balance,
          ),
          Balancecard(
            title: 'eSewa          ',
            amount: 8000,
            monthChange: 3200,
            icon: Icons.account_balance_wallet,
          ),
          Balancecard(
            title: 'NIBL          ',
            amount: 43000,
            monthChange: 2000,
            icon: Icons.account_balance,
          ),
          Balancecard(
            title: 'eSewa          ',
            amount: 8000,
            monthChange: 3200,
            icon: Icons.account_balance_wallet,
          ),
        ],
      ),
    )

        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        );
  }
}
