import 'package:flutter/material.dart';

class Balancecard extends StatelessWidget {
  final String title;
  final int amount;
  final int monthChange;
  final IconData icon;

  Balancecard({
    required this.title,
    required this.amount,
    required this.monthChange,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Icon(icon, size: 25.0),
              ],
            ),
            Text(
              'Rs. $amount',
              style: TextStyle(fontSize: 12.0, fontWeight: FontWeight.bold),
            ),
            Text(
              'Rs. $monthChange this month',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
