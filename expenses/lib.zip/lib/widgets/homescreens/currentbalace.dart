import 'package:flutter/material.dart';

class Currentbalace extends StatelessWidget {
  final int currentBalance;

  Currentbalace({
    required this.currentBalance,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Current Balance',
            ),
            Text('Rs. $currentBalance',
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold)),
            SizedBox(height: 8.0),
          ],
        ),
      ),
    );
  }
}
