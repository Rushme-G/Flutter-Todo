import 'package:expenses/base/style/text_styles.dart';
import 'package:flutter/material.dart';

class SummaryAccounts extends StatelessWidget {
  const SummaryAccounts({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      color: Colors.deepOrangeAccent,
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Current Balances',
            style: TypoStyles().kSectionheader,
          ),
          Container(
            height: 80,
            // width: 200,
            color: Colors.white,
            margin: EdgeInsets.only(bottom: 8),
          )
        ],
      ),
    );
  }
}
