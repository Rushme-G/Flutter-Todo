import 'package:flutter/material.dart';

class TypoStyles {
  TextStyle kPageHeader =
      const TextStyle(fontSize: 36, fontWeight: FontWeight.bold);

  TextStyle kSectionheader =
      const TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
}
