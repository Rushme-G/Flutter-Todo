class BaseConfig {
  final String baseUrl = "http://10.254.251.126:3030/";
}
